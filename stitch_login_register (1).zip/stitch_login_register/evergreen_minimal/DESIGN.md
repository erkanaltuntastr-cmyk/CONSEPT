# Design System: The Ethereal Athlete

## 1. Overview & Creative North Star
**The Creative North Star: "Botanical Precision"**

This design system rejects the frantic, high-intensity tropes of traditional fitness applications. Instead, it draws inspiration from high-end editorial magazines and forest retreats. We are moving away from "The Digital Template" toward a "Digital Sanctuary." 

The goal is to create a UI that feels like it’s breathing. We achieve this through **intentional asymmetry**, where large display typography is offset by generous whitespace, and **layered depth**, where elements don’t just sit on a screen—they inhabit a space. By utilizing the "Botanical" palette of deep greens and earthy neutrals, we ground the user’s physical effort in a sense of mental calm.

---

## 2. Colors: Tonal Architecture
The palette is rooted in nature. We prioritize a "soft-touch" interface that avoids the harshness of pure black or clinical white.

### The "No-Line" Rule
**Borders are prohibited for sectioning.** To create separation, use background shifts. A `surface-container-low` card sitting on a `surface` background provides enough contrast to be felt without being seen as a structural "fence." This creates a seamless, fluid user journey.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine paper.
*   **Base:** `surface` (#fcf9f8) – The foundation.
*   **Low Importance:** `surface-container-low` (#f6f3f2).
*   **High Importance/Floating:** `surface-container-lowest` (#ffffff).
*   **Depth:** Use `surface-dim` (#dbdad9) to "recede" background elements, pushing the content forward.

### The "Glass & Gradient" Rule
To elevate the "premium" feel, use **Glassmorphism** for navigation bars and floating action buttons. Apply `surface` at 70% opacity with a `24px` backdrop blur. 
*   **Signature Texture:** For hero moments or primary CTAs, use a subtle linear gradient: `primary` (#2e6a41) to `primary_dim` (#215d36) at a 135-degree angle. This adds "soul" and prevents the green from feeling flat.

---

## 3. Typography: Editorial Authority
We use a pairing of **Manrope** (Display/Headlines) and **Work Sans** (Body/Labels) to balance modern confidence with utilitarian readability.

*   **Display (Large/Medium/Small):** Manrope. Use these for motivational anchors and big "wins" (e.g., "7-Day Streak"). The scale is aggressive to create a sense of importance.
*   **Headline & Title:** Manrope. These are your navigational beacons. 
*   **Body (Large/Medium/Small):** Work Sans. Set with generous line-height (1.6x) to ensure the "calm" extends to reading workout descriptions.
*   **Labels:** Work Sans. Used for metadata and button text. Keep these concise and often all-caps with a `0.05rem` letter spacing for a premium feel.

---

## 4. Elevation & Depth
We define space through light and shadow, not lines.

*   **The Layering Principle:** Avoid shadows for static content. Simply nest a `surface-container-lowest` card inside a `surface-container` background.
*   **Ambient Shadows:** For elements that truly "float" (like a workout timer), use an extra-diffused shadow: `Offset: 0, 8px | Blur: 32px | Color: #323232 (at 6% opacity)`.
*   **The "Ghost Border" Fallback:** If accessibility requires a container boundary, use `outline-variant` (#b3b2b1) at **15% opacity**. It should be a whisper, not a statement.
*   **Depth Interaction:** When a user presses a card, it should not "sink" via a shadow; it should subtly scale down (98%) and shift color to `surface-container-high`.

---

## 5. Components: Botanical Primitives

### Buttons
*   **Primary:** `primary` background with `on_primary` text. `xl` (1.5rem) roundedness. No shadow.
*   **Secondary:** `primary_container` background with `on_primary_container` text.
*   **Tertiary:** Ghost style. No background, `primary` text, bold weight.

### Input Fields
*   **Style:** Filled containers using `surface-container-highest`. 
*   **Focus State:** A `2px` "Ghost Border" using `primary` at 40% opacity. 
*   **Error:** Use `error` (#9f403d) text only; do not turn the entire box red. It’s too jarring for a "calm" app.

### Cards & Lists
*   **The Divider Ban:** Strictly forbid 1px lines between list items. Use `24px` of vertical whitespace or alternating `surface-container` tones to distinguish items.
*   **Progress Indicators:** Use the `primary` green for active stats, but keep the track `surface-variant`.

### Specialty: The "Zen" Timer
A bespoke component for meditation or rest periods. Use a large `display-lg` typeface centered in a `surface-container-lowest` circle, utilizing a `primary` to `primary_container` gradient ring that slowly depletes.

---

## 6. Do’s and Don’ts

### Do
*   **Do** embrace "Wasted Space." Wide margins (min 24px) are a feature, not a bug.
*   **Do** use `primary_fixed_dim` for icons in a dark-mode context to maintain legibility.
*   **Do** align text-heavy sections to a clean left-axis while allowing images to bleed off-edge for an editorial look.

### Don’t
*   **Don’t** use pure #000000. Always use `on_surface` (#323232) for text to maintain a soft, premium feel.
*   **Don’t** use "Pop" animations. Use "Ease-Out-Expo" transitions (slow, smooth fades and slides) to mirror the calm of the app.
*   **Don’t** use standard Material icons. Use thin-stroke (1.5px or 2px) custom iconography to match the `Work Sans` weight.